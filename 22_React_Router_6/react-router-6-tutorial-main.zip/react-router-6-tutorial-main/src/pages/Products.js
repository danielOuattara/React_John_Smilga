const Products = () => {
  return (
    <>
      <section className='section'>
        <h2>products</h2>
      </section>
    </>
  );
};

export default Products;

const Error = () => {
  return (
    <section className='section'>
      <h2>Error</h2>
    </section>
  );
};
export default Error;

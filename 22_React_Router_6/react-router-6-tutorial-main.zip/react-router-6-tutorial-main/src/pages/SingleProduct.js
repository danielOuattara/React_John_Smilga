const SingleProduct = () => {
  return (
    <section className='section product'>
      <h2>single product</h2>
    </section>
  );
};

export default SingleProduct;

const Dashboard = () => {
  return (
    <section className='section'>
      <h4>Dashboard</h4>
    </section>
  );
};
export default Dashboard;

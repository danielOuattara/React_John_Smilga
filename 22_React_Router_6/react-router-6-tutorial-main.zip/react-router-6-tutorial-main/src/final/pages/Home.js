const Home = () => {
  return (
    <section className='section'>
      <h2>home page</h2>
    </section>
  );
};
export default Home;

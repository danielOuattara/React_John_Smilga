const products = [
  {
    id: 'recZkNf2kwmdBcqd0',
    name: 'accent chair',
    image:
      'https://dl.airtable.com/.attachmentThumbnails/e8bc3791196535af65f40e36993b9e1f/438bd160',
  },
  {
    id: 'recEHmzvupvT8ZONH',
    name: 'albany sectional',

    image:
      'https://dl.airtable.com/.attachmentThumbnails/0be1af59cf889899b5c9abb1e4db38a4/d631ac52',
  },
  {
    id: 'rec5NBwZ5zCD9nfF0',
    name: 'albany table',

    image:
      'https://dl.airtable.com/.attachmentThumbnails/7478483f40a2f56662a87b304bd4e104/707d397f',
  },
  {
    id: 'recd1jIVIEChmiwhe',
    name: 'armchair',

    image:
      'https://dl.airtable.com/.attachmentThumbnails/530c07c5ade5acd9934c8dd334458b86/cf91397f',
  },
  {
    id: 'recoM2MyHJGHLVi5l',
    name: 'bar stool',
    image:
      'https://dl.airtable.com/.attachmentThumbnails/a6119fabf7256049cc0e8dbcdf536c9c/b0153f66',
  },
];

export default products;

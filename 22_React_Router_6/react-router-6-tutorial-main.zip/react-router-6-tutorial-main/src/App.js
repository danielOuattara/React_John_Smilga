function App() {
  return <h2>React Router 6 Tutorial</h2>;
}

export default App;
